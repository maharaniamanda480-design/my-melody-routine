package com.example.mymelodyroutine

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RoutineWidgetProvider : AppWidgetProvider() {
    companion object {
        private const val ACTION_TOGGLE = "com.example.mymelodyroutine.TOGGLE"
        private const val ACTION_NEXT = "com.example.mymelodyroutine.NEXT"
        private const val ACTION_PREV = "com.example.mymelodyroutine.PREV"
        private const val ACTION_RESET = "com.example.mymelodyroutine.RESET"
        private const val PREFS = "routine_state"
        private const val TOTAL = 24
        private val tasks = listOf(
            "04.15 — Bangun tidur", "04.15 — Sholat Subuh", "Setelah Subuh — Al-Qur’an", "05.00–08.00 — Belajar UTBK",
            "08.15–08.45 — Siapkan makanan", "09.00–09.30 — Beres-beres rumah", "10.00–11.00 — Istirahat otak", "12.00 — Sholat Dzuhur",
            "12.00 — Makan siang", "12.00 — Vitamin & penambah darah", "13.00–14.00 — Latihan soal UTBK", "14.15–14.30 — Istirahat",
            "Persiapan olahraga", "15.00 — Sholat Ashar", "15.00 — Ganti pakaian olahraga", "15.15–16.30 — Jalan kaki",
            "16.30–16.45 — Pulang olahraga", "17.00 — Mandi", "17.00 — Snack & istirahat", "18.00 — Sholat Maghrib",
            "18.30 — Makan malam", "19.00–20.30 — Flashcard Pintarly", "20.45–21.00 — Persiapan tidur", "21.00 — Mulai tidur"
        )
        private val groups = listOf("PAGI", "PAGI", "PAGI", "PAGI", "PAGI", "PAGI", "PAGI", "SIANG", "SIANG", "SIANG", "SIANG", "SIANG", "SIANG", "SORE", "SORE", "SORE", "SORE", "SORE", "SORE", "MALAM", "MALAM", "MALAM", "MALAM", "MALAM")
        private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        private fun ensureDay(context: Context) {
            val p = prefs(context)
            if (p.getString("date", "") != today()) p.edit().clear().putString("date", today()).apply()
        }
        private fun checked(context: Context, index: Int) = prefs(context).getBoolean("task_$index", false)
        private fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, RoutineWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }
        private fun pending(context: Context, appWidgetId: Int, action: String, index: Int = -1): PendingIntent {
            val intent = Intent(context, RoutineWidgetProvider::class.java).setAction(action)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId).putExtra("index", index)
            val code = appWidgetId * 1000 + (action.hashCode() and 0x3ff) + index + 2
            return PendingIntent.getBroadcast(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            ensureDay(context)
            val p = prefs(context)
            val page = (p.getInt("page_$id", 0)).coerceIn(0, 5)
            val done = (0 until TOTAL).count { checked(context, it) }
            val views = RemoteViews(context.packageName, R.layout.routine_widget)
            views.setTextViewText(R.id.progress_text, "$done dari 24 selesai · ${done * 100 / TOTAL}%")
            views.setProgressBar(R.id.progress_bar, TOTAL, done, false)
            views.setTextViewText(R.id.page_text, "${groups[page * 4]} · ${page + 1}/6")
            val ids = intArrayOf(R.id.task0, R.id.task1, R.id.task2, R.id.task3)
            for (slot in 0..3) {
                val index = page * 4 + slot
                val isDone = checked(context, index)
                views.setTextViewText(ids[slot], (if (isDone) "☑ " else "□ ") + tasks[index])
                views.setTextColor(ids[slot], if (isDone) 0xffb98b9e.toInt() else 0xff63384b.toInt())
                views.setOnClickPendingIntent(ids[slot], pending(context, id, ACTION_TOGGLE, index))
            }
            views.setTextViewText(R.id.previous, if (page == 0) "♡" else "‹ Sebelumnya")
            views.setTextViewText(R.id.next, if (page == 5) "♡" else "Berikutnya ›")
            views.setOnClickPendingIntent(R.id.previous, pending(context, id, ACTION_PREV))
            views.setOnClickPendingIntent(R.id.next, pending(context, id, ACTION_NEXT))
            views.setOnClickPendingIntent(R.id.reset, pending(context, id, ACTION_RESET))
            manager.updateAppWidget(id, views)
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        ensureDay(context)
        val p = prefs(context)
        when (intent.action) {
            ACTION_TOGGLE -> {
                val index = intent.getIntExtra("index", -1)
                if (index in 0 until TOTAL) p.edit().putBoolean("task_$index", !checked(context, index)).apply()
            }
            ACTION_NEXT -> if (id != AppWidgetManager.INVALID_APPWIDGET_ID) p.edit().putInt("page_$id", (p.getInt("page_$id", 0) + 1).coerceAtMost(5)).apply()
            ACTION_PREV -> if (id != AppWidgetManager.INVALID_APPWIDGET_ID) p.edit().putInt("page_$id", (p.getInt("page_$id", 0) - 1).coerceAtLeast(0)).apply()
            ACTION_RESET -> p.edit().clear().putString("date", today()).apply()
        }
        updateAll(context)
    }
}
