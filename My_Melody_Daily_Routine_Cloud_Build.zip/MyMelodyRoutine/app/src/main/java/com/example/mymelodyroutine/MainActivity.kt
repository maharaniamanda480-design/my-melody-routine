package com.example.mymelodyroutine

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val message = TextView(this).apply {
            text = "🐰  My Melody Daily Routine  ♡\n\nUntuk memasang widget:\n1. Kembali ke homescreen\n2. Tekan lama area kosong\n3. Pilih Widget\n4. Cari My Melody Daily Routine\n5. Tarik widget ke homescreen\n\nCentang tugas langsung dari widget ya! 🎀"
            textSize = 18f
            setTextColor(0xff9f496f.toInt())
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xfffff1f6.toInt())
        }
        setContentView(message)
    }
}
